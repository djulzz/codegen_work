/**
 * @file bus_timesTwo.h
 */

#ifndef BUS_TIMESTWO_H
#define BUS_TIMESTWO_H

#ifdef  MATLAB_MEX_FILE
#include "tmwtypes.h"
#else
#include "rtwtypes.h"
#endif

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
struct bus_timesTwo
{
    real_T E1;
    real_T E2;
};

#endif /* BUS_TIMESTWO_H defined */
