clear all;
clc;

bus_timesTwo = create_bus_timesTwo(  );
build_timestwoAsBus(  );