function bus_timesTwo = create_bus_timesTwo(  )
    bus_timesTwo            = Simulink.Bus;
    bus_timesTwo.HeaderFile = 'external_implementations.h';
    bus_timesTwo.DataScope  = 'Imported';

    names           = { 'E1', 'E2' };
    dimensions      = [1, 1];
    types           = { 'double', 'double' };
    complexities    = { 'real', 'real' };

    for ii = 2 : -1 : 1
        e( ii ) = Simulink.BusElement;
        e( ii ).Name = names{ ii };
        e( ii ).Dimensions = dimensions( ii );
        e( ii ).DataType = types{ ii };
        e( ii ).Complexity = complexities{ ii };
    end
    bus_timesTwo.Elements = e;
end
