/*
 * demo_timetwoAsBus.h
 *
 * Code generation for model "demo_timetwoAsBus".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri May 12 14:19:43 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_demo_timetwoAsBus_h_
#define RTW_HEADER_demo_timetwoAsBus_h_
#ifndef demo_timetwoAsBus_COMMON_INCLUDES_
#define demo_timetwoAsBus_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* demo_timetwoAsBus_COMMON_INCLUDES_ */

#include "demo_timetwoAsBus_types.h"
#include "external_implementations.h"
#include <float.h>
#include <string.h>
#include <stddef.h>
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* user code (top of header file) */
#include "bus_timesTwo.h"

/* Block states (default storage) for system '<Root>' */
typedef struct {
  void* SFunctionBuilder_y1BUS;        /* '<Root>/S-Function Builder' */
} DW_demo_timetwoAsBus_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  bus_timesTwo Outport;                /* '<Root>/Outport' */
} ExtY_demo_timetwoAsBus_T;

/* Parameters (default storage) */
struct P_demo_timetwoAsBus_T_ {
  real_T Constant_Value;               /* Expression: 2
                                        * Referenced by: '<Root>/Constant'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_demo_timetwoAsBus_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_demo_timetwoAsBus_T demo_timetwoAsBus_P;

/* Block states (default storage) */
extern DW_demo_timetwoAsBus_T demo_timetwoAsBus_DW;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_demo_timetwoAsBus_T demo_timetwoAsBus_Y;

/* External data declarations for dependent source files */
extern const bus_timesTwo demo_timetwoAsBus_rtZbus_timesT;/* bus_timesTwo ground */

/* Model entry point functions */
extern void demo_timetwoAsBus_initialize(void);
extern void demo_timetwoAsBus_step(void);
extern void demo_timetwoAsBus_terminate(void);

/* Real-time Model object */
extern RT_MODEL_demo_timetwoAsBus_T *const demo_timetwoAsBus_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'demo_timetwoAsBus'
 */
#endif                                 /* RTW_HEADER_demo_timetwoAsBus_h_ */
