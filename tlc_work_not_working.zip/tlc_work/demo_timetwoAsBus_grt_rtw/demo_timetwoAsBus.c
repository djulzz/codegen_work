/*
 * demo_timetwoAsBus.c
 *
 * Code generation for model "demo_timetwoAsBus".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri May 12 14:19:43 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "demo_timetwoAsBus.h"
#include "external_implementations.h"
#include "demo_timetwoAsBus_private.h"
#include <string.h>
#include "rt_nonfinite.h"

/* Block states (default storage) */
DW_demo_timetwoAsBus_T demo_timetwoAsBus_DW;

/* External outputs (root outports fed by signals with default storage) */
ExtY_demo_timetwoAsBus_T demo_timetwoAsBus_Y;

/* Real-time model */
static RT_MODEL_demo_timetwoAsBus_T demo_timetwoAsBus_M_;
RT_MODEL_demo_timetwoAsBus_T *const demo_timetwoAsBus_M = &demo_timetwoAsBus_M_;
const bus_timesTwo demo_timetwoAsBus_rtZbus_timesT = { 0.0,/* E1 */
  0.0                                  /* E2 */
};

/* Model step function */
void demo_timetwoAsBus_step(void)
{
  /* S-Function (timestwoAsBus): '<Root>/S-Function Builder' incorporates:
   *  Constant: '<Root>/Constant'
   *  Outport: '<Root>/Outport'
   */
  wrapper_output_model_accel( &demo_timetwoAsBus_P.Constant_Value,
    &demo_timetwoAsBus_Y.Outport );

  /* Matfile logging */
  rt_UpdateTXYLogVars(demo_timetwoAsBus_M->rtwLogInfo,
                      (&demo_timetwoAsBus_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [1.0s, 0.0s] */
    if ((rtmGetTFinal(demo_timetwoAsBus_M)!=-1) &&
        !((rtmGetTFinal(demo_timetwoAsBus_M)-
           demo_timetwoAsBus_M->Timing.taskTime0) >
          demo_timetwoAsBus_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(demo_timetwoAsBus_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++demo_timetwoAsBus_M->Timing.clockTick0)) {
    ++demo_timetwoAsBus_M->Timing.clockTickH0;
  }

  demo_timetwoAsBus_M->Timing.taskTime0 = demo_timetwoAsBus_M->Timing.clockTick0
    * demo_timetwoAsBus_M->Timing.stepSize0 +
    demo_timetwoAsBus_M->Timing.clockTickH0 *
    demo_timetwoAsBus_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void demo_timetwoAsBus_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)demo_timetwoAsBus_M, 0,
                sizeof(RT_MODEL_demo_timetwoAsBus_T));
  rtmSetTFinal(demo_timetwoAsBus_M, 10.0);
  demo_timetwoAsBus_M->Timing.stepSize0 = 1.0;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    demo_timetwoAsBus_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(demo_timetwoAsBus_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(demo_timetwoAsBus_M->rtwLogInfo, (NULL));
    rtliSetLogT(demo_timetwoAsBus_M->rtwLogInfo, "tout");
    rtliSetLogX(demo_timetwoAsBus_M->rtwLogInfo, "");
    rtliSetLogXFinal(demo_timetwoAsBus_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(demo_timetwoAsBus_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(demo_timetwoAsBus_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(demo_timetwoAsBus_M->rtwLogInfo, 0);
    rtliSetLogDecimation(demo_timetwoAsBus_M->rtwLogInfo, 1);
    rtliSetLogY(demo_timetwoAsBus_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(demo_timetwoAsBus_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(demo_timetwoAsBus_M->rtwLogInfo, (NULL));
  }

  /* states (dwork) */
  (void) memset((void *)&demo_timetwoAsBus_DW, 0,
                sizeof(DW_demo_timetwoAsBus_T));

  /* external outputs */
  demo_timetwoAsBus_Y.Outport = demo_timetwoAsBus_rtZbus_timesT;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(demo_timetwoAsBus_M->rtwLogInfo, 0.0,
    rtmGetTFinal(demo_timetwoAsBus_M), demo_timetwoAsBus_M->Timing.stepSize0,
    (&rtmGetErrorStatus(demo_timetwoAsBus_M)));
}

/* Model terminate function */
void demo_timetwoAsBus_terminate(void)
{
  /* (no terminate code required) */
}
