/*
 * demo_timetwoAsBus_private.h
 *
 * Code generation for model "demo_timetwoAsBus".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri May 12 14:19:43 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_demo_timetwoAsBus_private_h_
#define RTW_HEADER_demo_timetwoAsBus_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "demo_timetwoAsBus_types.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

#include "bus_timesTwo.h"
#include "external_implementations.h"

void wrapper_start_model( void );
void wrapper_output_model( void* __u1, void* __y1BUS );
void wrapper_terminate_model( void );

#endif                             /* RTW_HEADER_demo_timetwoAsBus_private_h_ */
