/*
 * demo_timetwoAsBus_data.c
 *
 * Code generation for model "demo_timetwoAsBus".
 *
 * Model version              : 1.2
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri May 12 14:19:43 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "demo_timetwoAsBus.h"

/* Block parameters (default storage) */
P_demo_timetwoAsBus_T demo_timetwoAsBus_P = {
  /* Expression: 2
   * Referenced by: '<Root>/Constant'
   */
  2.0
};
