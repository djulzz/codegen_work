% @file script_legacy_tool_generate_timestwoAsBus_wrapper.m


% clc;
% bus_timesTwo = create_bus_timesTwo(  );
% 
% def = legacy_code( 'initialize' );
% def.SFunctionName = 'timestwoAsBus';
% def.OutputFcnSpec = 'void wrapper_output_model(double u1[1], bus_timesTwo y1[1])';
% def.HeaderFiles   = {'external_implementations.h'};
% def.SourceFiles   = {'external_implementations.cpp'};
% def.IncPaths      = {'sldemo_lct_src'};
% def.SrcPaths      = {'sldemo_lct_src'};
% legacy_code( 'generate_for_sim', def );