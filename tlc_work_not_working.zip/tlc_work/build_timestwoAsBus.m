function build_timestwoAsBus(  )
    mex timestwoAsBus.cpp external_implementations.cpp
    return;
end

