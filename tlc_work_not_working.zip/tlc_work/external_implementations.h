/**
 * external_implementations.h
 */

#ifndef EXTERNAL_IMPLEMENTATIONS_H
#define EXTERNAL_IMPLEMENTATIONS_H

#include "bus_timesTwo.h"

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void wrapper_start_model( void );
void wrapper_output_model( void* __u1, void* __y1BUS );
void wrapper_terminate_model( void );

#endif /* EXTERNAL_IMPLEMENTATIONS_H defined */