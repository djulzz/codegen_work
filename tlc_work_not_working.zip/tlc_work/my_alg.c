
#ifdef  MATLAB_MEX_FILE
#include "tmwtypes.h"
#else
#include "rtwtypes.h"
#endif

real_T my_alg( real_T u1 )
{
    return 2.0 * u1;
}
